"use client"

import { useEffect, useRef, useState } from "react"
import { ChevronDown } from "lucide-react"

const faqs = [
  {
    question: "What AI services do you offer?",
    answer:
      "We offer AI integration, AI voice agents for handling customer calls 24/7, AI chat agents for lead capture and support, and AI-powered digital marketing analytics. All solutions are custom-built for your business.",
  },
  {
    question: "How do AI voice and chat agents work?",
    answer:
      "Our AI voice agents handle inbound and outbound calls with natural, human-like conversations -- qualifying leads, answering FAQs, and booking appointments. Our chat agents live on your website, engaging visitors instantly and guiding them through your sales funnel.",
  },
  {
    question: "Why not just hire a full-time developer?",
    answer:
      "Hiring in-house is costly -- experienced designers can exceed $100k and developers $120k annually, not including benefits. We deliver senior-level expertise in web design, AI integration, and marketing at a fraction of the cost.",
  },
  {
    question: "How fast can you deliver my project?",
    answer:
      "Timelines depend on scope, but most projects wrap up within 2-6 weeks. After our initial discussion, you will receive a clear timeline with milestones. AI agent deployments can be ready in as little as 1-2 weeks.",
  },
  {
    question: "What if I am not satisfied with the outcome?",
    answer:
      "We include unlimited revisions within the project scope. We will refine until the final product matches your vision -- whether it is your website, AI agents, or marketing strategy.",
  },
  {
    question: "Do you provide support after the launch?",
    answer:
      "Absolutely. We offer end-to-end support and maintenance plans so your website and AI agents stay optimized, secure, and up-to-date long after launch.",
  },
]

function FaqItem({
  question,
  answer,
  isOpen,
  onClick,
}: {
  question: string
  answer: string
  isOpen: boolean
  onClick: () => void
}) {
  return (
    <div className="border-b border-[#222] last:border-b-0">
      <button
        onClick={onClick}
        className="w-full flex items-center justify-between py-6 px-2 text-left group"
      >
        <span className="text-base font-medium text-foreground group-hover:text-[#3352cc] transition-colors pr-4">
          {question}
        </span>
        <ChevronDown
          size={20}
          className={`flex-shrink-0 text-[#888] transition-transform duration-300 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </button>
      <div
        className={`overflow-hidden transition-all duration-300 ${
          isOpen ? "max-h-96 pb-6" : "max-h-0"
        }`}
      >
        <p className="text-sm text-[#888] leading-relaxed px-2">{answer}</p>
      </div>
    </div>
  )
}

export default function Faq() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = sectionRef.current?.querySelectorAll(".reveal")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="faq" className="relative py-24 px-6 overflow-hidden">
      {/* Background accent */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full bg-[#6b4fa0]/[0.015] blur-[120px]" />
      </div>

      <div className="max-w-3xl mx-auto relative z-10">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="reveal opacity-0 text-3xl md:text-5xl font-bold text-foreground text-balance">
            Frequently Asked Questions
          </h2>
          <p className="reveal opacity-0 delay-100 mt-4 text-[#888] leading-relaxed">
            Here are some of the most common questions we get.
          </p>
        </div>

        {/* FAQ items */}
        <div className="reveal opacity-0 delay-200 rounded-2xl border border-[#222] bg-[#111] px-6">
          {faqs.map((faq, index) => (
            <FaqItem
              key={index}
              question={faq.question}
              answer={faq.answer}
              isOpen={openIndex === index}
              onClick={() =>
                setOpenIndex(openIndex === index ? null : index)
              }
            />
          ))}
        </div>
      </div>
    </section>
  )
}
