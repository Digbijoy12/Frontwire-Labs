"use client"

import { useEffect, useRef } from "react"
import { ArrowRight, Sparkles, Phone, Calendar } from "lucide-react"
import HeroVideoAnimation from "./hero-video-animation"

export default function Hero() {
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = heroRef.current?.querySelectorAll(".reveal")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-32 pb-16 overflow-hidden"
    >
      <div className="relative z-10 max-w-6xl mx-auto text-center flex flex-col items-center gap-8">
        {/* Badge */}
        <div className="reveal opacity-0 inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-[#333] bg-[#111]/80 backdrop-blur-sm text-sm text-[#e0e0e0]">
          <Sparkles size={14} className="text-[#c47a20]" />
          Available for New Projects
        </div>

        {/* Heading -- large and bold with bright white */}
        <h1 className="reveal opacity-0 delay-100 text-4xl sm:text-5xl md:text-6xl lg:text-7xl xl:text-8xl font-bold leading-[1.08] tracking-tight text-[#ffffff] text-balance max-w-5xl">
          Transforming Your Ideas into{" "}
          <span className="gradient-text">Stunning Digital Experiences</span>
        </h1>

        {/* Subheading -- bright and readable */}
        <p className="reveal opacity-0 delay-200 text-lg md:text-xl lg:text-2xl text-[#cccccc] max-w-3xl leading-relaxed text-pretty">
          From intelligent automation to stunning design, we deliver the full
          stack of digital innovation.
        </p>

        {/* Dual CTA Buttons */}
        <div className="reveal opacity-0 delay-300 flex flex-col sm:flex-row items-center gap-4 mt-2">
          <a
            href="tel:+13527902398"
            className="group inline-flex items-center gap-3 px-8 py-4 text-base font-semibold rounded-full bg-[#3352cc] text-[#ffffff] hover:bg-[#2a44aa] transition-all btn-glow"
          >
            <Phone size={18} className="group-hover:animate-pulse" />
            Call Now
          </a>
          <a
            href="https://cal.com/frontwire-labs"
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-3 px-8 py-4 text-base font-semibold rounded-full bg-[#ffffff] text-[#0a0a0a] hover:bg-[#e0e0e0] transition-all"
          >
            <Calendar size={18} />
            Book Appointment
            <ArrowRight
              size={16}
              className="group-hover:translate-x-1 transition-transform"
            />
          </a>
        </div>

        {/* Trust badges -- bright white text */}
        <div className="reveal opacity-0 delay-400 flex flex-wrap items-center justify-center gap-4 md:gap-6 mt-2 text-sm text-[#b0b0b0]">
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2">
              <div className="w-7 h-7 rounded-full bg-[#3352cc]/20 border-2 border-[#0a0a0a] flex items-center justify-center text-xs text-[#3352cc] font-bold">
                S
              </div>
              <div className="w-7 h-7 rounded-full bg-[#c47a20]/20 border-2 border-[#0a0a0a] flex items-center justify-center text-xs text-[#c47a20] font-bold">
                F
              </div>
            </div>
            <span className="text-[#d0d0d0]">Senior talent</span>
          </div>
          <div className="w-px h-4 bg-[#444]" />
          <span className="text-[#d0d0d0]">AI-Powered Solutions</span>
          <div className="w-px h-4 bg-[#444]" />
          <span className="text-[#d0d0d0]">Fast Delivery</span>
        </div>

        {/* Video animation panel -- FULL WIDTH and taller */}
        <div className="reveal opacity-0 delay-500 w-full mt-8">
          <HeroVideoAnimation />
        </div>

        {/* Scroll indicator */}
        <a
          href="#services-marquee"
          className="reveal opacity-0 delay-600 inline-flex flex-col items-center gap-2 text-xs text-[#999] hover:text-[#ccc] transition-colors mt-4"
        >
          <span>Scroll to explore</span>
          <div className="w-5 h-8 rounded-full border border-[#444] flex items-start justify-center p-1">
            <div className="w-1 h-2 rounded-full bg-[#999] animate-bounce" />
          </div>
        </a>
      </div>
    </section>
  )
}
