"use client"

import { useEffect, useRef } from "react"
import { Check, X, Minus, Phone, Calendar } from "lucide-react"

const features = [
  {
    name: "Project Timeline",
    frontwire: "2-4 weeks",
    agency: "6-12 weeks",
    freelancer: "8-16 weeks",
  },
  {
    name: "AI Integration",
    frontwire: "Included",
    agency: "Not Available",
    freelancer: "Not Available",
  },
  {
    name: "AI Voice & Chat Agents",
    frontwire: "Included",
    agency: "Extra Cost",
    freelancer: "Not Available",
  },
  {
    name: "Digital Marketing",
    frontwire: "Included",
    agency: "Extra Cost",
    freelancer: "Not Included",
  },
  {
    name: "Conversion Optimization",
    frontwire: "Included",
    agency: "Extra Cost",
    freelancer: "Not Available",
  },
  {
    name: "Design Quality",
    frontwire: "Premium",
    agency: "Standard",
    freelancer: "Basic",
  },
  {
    name: "Technical Support",
    frontwire: "24/7",
    agency: "Business Hours",
    freelancer: "Limited",
  },
  {
    name: "SEO Optimization",
    frontwire: "Included",
    agency: "Basic",
    freelancer: "Not Included",
  },
  {
    name: "Mobile Responsive",
    frontwire: "Perfect",
    agency: "Good",
    freelancer: "Basic",
  },
]

function StatusIcon({ value }: { value: string }) {
  if (["Included", "24/7", "Perfect", "Premium", "Expert Level", "2-4 weeks"].includes(value)) {
    return <Check size={16} className="text-[#22c55e]" />
  }
  if (["Not Available", "Not Included"].includes(value)) {
    return <X size={16} className="text-[#ef4444]" />
  }
  return <Minus size={16} className="text-[#888]" />
}

export default function Comparison() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = sectionRef.current?.querySelectorAll(".reveal")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="comparison" className="relative py-24 px-6 overflow-hidden">
      {/* Background accent */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/3 left-1/4 w-[500px] h-[500px] rounded-full bg-[#3352cc]/[0.02] blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-[#c47a20]/[0.015] blur-[100px]" />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="reveal opacity-0 text-3xl md:text-5xl font-bold text-foreground text-balance">
            What makes us <span className="gradient-text">different?</span>
          </h2>
          <p className="reveal opacity-0 delay-100 mt-4 text-[#888] max-w-xl mx-auto leading-relaxed">
            See how we stack up against the competition
          </p>
        </div>

        {/* Comparison table */}
        <div className="reveal opacity-0 delay-200 rounded-2xl border border-[#222] bg-[#111] overflow-hidden">
          {/* Table header */}
          <div className="grid grid-cols-4 gap-4 p-6 border-b border-[#222] bg-[#0d0d0d]">
            <div className="text-sm font-semibold text-foreground">Features</div>
            <div className="text-sm font-semibold text-center">
              <span className="gradient-text">FrontWire Labs</span>
            </div>
            <div className="text-sm font-semibold text-center text-[#888]">Generic Agency</div>
            <div className="text-sm font-semibold text-center text-[#888]">Freelancer</div>
          </div>

          {/* Table rows */}
          {features.map((feature, index) => (
            <div
              key={feature.name}
              className={`grid grid-cols-4 gap-4 p-6 ${
                index < features.length - 1 ? "border-b border-[#222]" : ""
              } hover:bg-[#ffffff04] transition-colors`}
            >
              <div className="text-sm text-foreground font-medium">{feature.name}</div>
              <div className="text-sm text-center text-[#22c55e] flex items-center justify-center gap-2">
                <StatusIcon value={feature.frontwire} />
                <span className="hidden sm:inline">{feature.frontwire}</span>
              </div>
              <div className="text-sm text-center text-[#888] flex items-center justify-center gap-2">
                <StatusIcon value={feature.agency} />
                <span className="hidden sm:inline">{feature.agency}</span>
              </div>
              <div className="text-sm text-center text-[#666] flex items-center justify-center gap-2">
                <StatusIcon value={feature.freelancer} />
                <span className="hidden sm:inline">{feature.freelancer}</span>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="reveal opacity-0 delay-300 flex flex-col sm:flex-row items-center justify-center gap-4 mt-10">
          <a
            href="tel:+13527902398"
            className="inline-flex items-center gap-2 px-8 py-4 text-base font-medium rounded-full bg-[#3352cc] text-[#ffffff] hover:bg-[#3352cc]/90 transition-colors btn-glow"
          >
            <Phone size={18} />
            Call Now
          </a>
          <a
            href="https://cal.com/frontwire-labs"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 text-base font-medium rounded-full bg-foreground text-background hover:bg-foreground/90 transition-colors"
          >
            <Calendar size={18} />
            Book Appointment
          </a>
        </div>
      </div>
    </section>
  )
}
