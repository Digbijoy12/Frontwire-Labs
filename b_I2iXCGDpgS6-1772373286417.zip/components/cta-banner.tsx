"use client"

import { useEffect, useRef } from "react"
import { Phone, Calendar, ArrowRight } from "lucide-react"

export default function CtaBanner() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = sectionRef.current?.querySelectorAll(".reveal")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="relative py-24 px-6 overflow-hidden">
      {/* Decorative glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px] rounded-full bg-[#3352cc]/[0.03] blur-[100px]" />
      </div>
      <div className="max-w-4xl mx-auto text-center">
        <div className="reveal opacity-0 inline-flex items-center gap-2 px-4 py-2 mb-6 rounded-full border border-[#222] bg-[#111]/80 backdrop-blur-sm text-sm text-[#888]">
          100% free & non-binding
        </div>

        <h2 className="reveal opacity-0 delay-100 text-3xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight text-balance">
          Your issue is not with generating traffic...
        </h2>

        <p className="reveal opacity-0 delay-200 mt-6 text-xl md:text-2xl text-[#888] leading-relaxed">
          {"it's with converting that traffic into valuable clients."}
        </p>

        <p className="reveal opacity-0 delay-300 mt-4 text-lg text-[#3352cc] font-medium">
          {"but that's where we come in!"}
        </p>

        <div className="reveal opacity-0 delay-400 mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="tel:+13527902398"
            className="group inline-flex items-center gap-3 px-8 py-4 text-base font-medium rounded-full bg-[#3352cc] text-[#ffffff] hover:bg-[#3352cc]/90 transition-all btn-glow"
          >
            <Phone size={18} />
            Call Now
          </a>
          <a
            href="https://cal.com/frontwire-labs"
            target="_blank"
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-3 px-8 py-4 text-base font-medium rounded-full bg-foreground text-background hover:bg-foreground/90 transition-all"
          >
            <Calendar size={18} />
            Book Appointment
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  )
}
