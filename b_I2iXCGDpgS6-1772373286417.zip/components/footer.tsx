import Image from "next/image"
import { Phone, Calendar } from "lucide-react"

const footerLinks = [
  {
    title: "Services",
    links: [
      { label: "AI Integration", href: "#services" },
      { label: "AI Voice Agents", href: "#services" },
      { label: "AI Chat Agents", href: "#services" },
      { label: "Digital Marketing", href: "#services" },
      { label: "Web Design", href: "#services" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "#" },
      { label: "Our Work", href: "#results" },
      { label: "Comparison", href: "#comparison" },
      { label: "Contact", href: "#contact" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "FAQ", href: "#faq" },
      { label: "Blog", href: "#" },
      { label: "Privacy Policy", href: "#" },
    ],
  },
]

export default function Footer() {
  return (
    <footer className="relative border-t border-[#222] bg-[#0a0a0a]">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <Image
              src="/images/logo.png"
              alt="FrontWire Labs"
              width={160}
              height={40}
              className="h-8 w-auto mb-4"
            />
            <p className="text-sm text-[#888] max-w-xs leading-relaxed mb-6">
              We design, develop, and launch AI-powered, high-performance websites
              crafted to engage users and accelerate business growth.
            </p>
            {/* Contact buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="tel:+13527902398"
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-full border border-[#333] text-[#aaa] hover:text-foreground hover:border-[#555] transition-colors"
              >
                <Phone size={12} />
                +1 (352) 790-2398
              </a>
              <a
                href="https://cal.com/frontwire-labs"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-full border border-[#333] text-[#aaa] hover:text-foreground hover:border-[#555] transition-colors"
              >
                <Calendar size={12} />
                Book a Call
              </a>
            </div>
          </div>

          {/* Links */}
          {footerLinks.map((group) => (
            <div key={group.title}>
              <h4 className="text-sm font-semibold text-foreground mb-4">
                {group.title}
              </h4>
              <ul className="flex flex-col gap-3">
                {group.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-sm text-[#888] hover:text-foreground transition-colors"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-8 border-t border-[#222] flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#666]">
            {"\u00A9"} {new Date().getFullYear()} FrontWire Labs. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a href="#" className="text-xs text-[#666] hover:text-foreground transition-colors">
              Privacy
            </a>
            <a href="#" className="text-xs text-[#666] hover:text-foreground transition-colors">
              Terms
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
