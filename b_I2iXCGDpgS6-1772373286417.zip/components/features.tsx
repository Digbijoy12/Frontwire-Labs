"use client"

import { useEffect, useRef } from "react"
import {
  Target,
  Zap,
  CreditCard,
  Bot,
  Headphones,
  Shield,
} from "lucide-react"

const features = [
  {
    icon: Target,
    title: "Conversion-Driven Design",
    description:
      "Crafted to turn visitors into loyal customers. Every detail designed for measurable ROI and lasting growth.",
  },
  {
    icon: Bot,
    title: "AI-First Approach",
    description:
      "We integrate AI into every layer -- from voice agents that handle calls to chatbots that convert leads while you sleep.",
  },
  {
    icon: Zap,
    title: "Lightning-Fast Delivery",
    description:
      "Fast turnarounds, flawless quality. So you can move fast, launch sooner, and stay ahead of the competition.",
  },
  {
    icon: CreditCard,
    title: "Clear, Honest Pricing",
    description:
      "One flat rate, no hidden fees, no surprises. Predictable pricing that makes budgeting effortless.",
  },
  {
    icon: Headphones,
    title: "Post-Launch Support",
    description:
      "We stay with you even after launch. Get quick help, updates, and ongoing improvements as your business grows.",
  },
  {
    icon: Shield,
    title: "Enterprise-Grade Security",
    description:
      "Your AI agents and websites are built with top-tier security practices, data protection, and compliance in mind.",
  },
]

export default function Features() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.05 }
    )

    const elements = sectionRef.current?.querySelectorAll(".reveal")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="relative py-24 px-6 overflow-hidden">
      {/* Background accents */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute -top-20 right-0 w-[500px] h-[500px] rounded-full bg-[#6b4fa0]/[0.02] blur-[100px]" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full bg-[#3352cc]/[0.02] blur-[80px]" />
      </div>

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="reveal opacity-0 text-3xl md:text-5xl font-bold text-foreground text-balance">
            Why Choose <span className="gradient-text">FrontWire Labs?</span>
          </h2>
          <p className="reveal opacity-0 delay-100 mt-4 text-[#888] max-w-xl mx-auto leading-relaxed">
            We blend cutting-edge AI with world-class design to deliver results that matter.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="reveal opacity-0 group p-8 rounded-2xl border border-[#222] bg-[#111]/80 backdrop-blur-sm hover:border-[#333] transition-all duration-300 card-glow"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-12 h-12 rounded-xl bg-[#3352cc]/10 flex items-center justify-center text-[#3352cc] mb-5 group-hover:bg-[#3352cc]/20 transition-colors">
                <feature.icon size={24} />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-3">
                {feature.title}
              </h3>
              <p className="text-sm text-[#888] leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
