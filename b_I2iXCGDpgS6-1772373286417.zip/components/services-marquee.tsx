"use client"

const servicesRow1 = [
  "AI Integration",
  "AI Voice Agents",
  "AI Chat Agents",
  "Web Design",
  "Development",
  "Digital Marketing",
  "Landing Pages",
  "UI UX Design",
  "Product Design",
  "Custom Website",
  "CMS Setup",
  "SEO Optimization",
]

const servicesRow2 = [
  "Logos",
  "Copywriting",
  "Motion Graphics",
  "Hosting",
  "Site Migration",
  "Deployment",
  "Branding",
  "E-commerce",
  "Maintenance",
  "Analytics Setup",
  "Conversion Optimization",
  "Performance Tuning",
]

export default function ServicesMarquee() {
  return (
    <section id="services-marquee" className="relative py-16 border-y border-[#1a1a1a] overflow-hidden bg-[#060608]">
      <div className="text-center mb-10">
        <p className="text-sm text-[#888] uppercase tracking-widest mb-3">
          All your digital needs handled
        </p>
        <h2 className="text-3xl md:text-5xl font-bold text-foreground">
          In record{" "}
          <span className="gradient-text font-serif italic">time.</span>
        </h2>
      </div>

      {/* Row 1 - left to right */}
      <div className="relative flex overflow-hidden mb-4">
        <div className="animate-marquee flex items-center gap-4 whitespace-nowrap">
          {[...servicesRow1, ...servicesRow1].map((service, i) => (
            <span
              key={`r1-${i}`}
              className="inline-flex items-center gap-3 px-6 py-3 rounded-full border border-[#222] bg-[#111] text-sm text-[#ccc] hover:border-[#3352cc]/50 hover:text-foreground transition-colors cursor-default"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#3352cc]" />
              {service}
            </span>
          ))}
        </div>
      </div>

      {/* Row 2 - right to left */}
      <div className="relative flex overflow-hidden">
        <div className="animate-marquee-reverse flex items-center gap-4 whitespace-nowrap">
          {[...servicesRow2, ...servicesRow2].map((service, i) => (
            <span
              key={`r2-${i}`}
              className="inline-flex items-center gap-3 px-6 py-3 rounded-full border border-[#222] bg-[#111] text-sm text-[#ccc] hover:border-[#c47a20]/50 hover:text-foreground transition-colors cursor-default"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-[#c47a20]" />
              {service}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
