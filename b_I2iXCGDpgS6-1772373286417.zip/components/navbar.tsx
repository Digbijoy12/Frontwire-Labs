"use client"

import { useState, useEffect } from "react"
import { Menu, X, Phone, Calendar } from "lucide-react"
import Image from "next/image"

const navLinks = [
  { label: "Services", href: "#services" },
  { label: "Our Work", href: "#results" },
  { label: "Comparison", href: "#comparison" },
  { label: "FAQs", href: "#faq" },
]

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileOpen, setIsMobileOpen] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-[#0a0a0a]/80 backdrop-blur-xl border-b border-[#222]"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between px-6 py-4">
        {/* Logo */}
        <a href="#" className="flex items-center gap-3">
          <Image
            src="/images/logo.png"
            alt="FrontWire Labs"
            width={220}
            height={55}
            className="h-11 md:h-12 w-auto"
          />
        </a>

        {/* Desktop Links */}
        <div className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="px-4 py-2 text-sm text-[#aaa] hover:text-foreground transition-colors rounded-lg hover:bg-[#ffffff08]"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="hidden lg:flex items-center gap-3">
          <a
            href="tel:+13527902398"
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-full border border-[#333] text-foreground hover:bg-[#ffffff08] transition-colors"
          >
            <Phone size={14} />
            Call Now
          </a>
          <a
            href="https://cal.com/frontwire-labs"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium rounded-full bg-foreground text-background hover:bg-foreground/90 transition-colors"
          >
            <Calendar size={14} />
            Book a Call
          </a>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          className="lg:hidden p-2 text-foreground"
          aria-label="Toggle menu"
        >
          {isMobileOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileOpen && (
        <div className="lg:hidden bg-[#0a0a0a]/95 backdrop-blur-xl border-t border-[#222]">
          <div className="flex flex-col px-6 py-4 gap-2">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setIsMobileOpen(false)}
                className="px-4 py-3 text-[#aaa] hover:text-foreground transition-colors rounded-lg hover:bg-[#ffffff08]"
              >
                {link.label}
              </a>
            ))}
            <div className="flex flex-col gap-3 mt-3 pt-3 border-t border-[#222]">
              <a
                href="tel:+13527902398"
                onClick={() => setIsMobileOpen(false)}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium rounded-full border border-[#333] text-foreground"
              >
                <Phone size={14} />
                Call Now
              </a>
              <a
                href="https://cal.com/frontwire-labs"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsMobileOpen(false)}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium rounded-full bg-foreground text-background"
              >
                <Calendar size={14} />
                Book a Call
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  )
}
