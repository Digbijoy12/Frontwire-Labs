"use client"

import { useEffect, useRef } from "react"
import { Bot, Mic, MessageSquare, BarChart3, Globe, Megaphone } from "lucide-react"

const showcaseItems = [
  {
    icon: Bot,
    title: "AI Integration",
    description:
      "We embed intelligent AI capabilities directly into your website -- from smart recommendations to automated workflows that save you hours every week.",
    color: "#3352cc",
    side: "left" as const,
  },
  {
    icon: Mic,
    title: "AI Voice Agents",
    description:
      "Deploy voice-powered AI agents that handle customer calls, qualify leads, and provide 24/7 support with natural, human-like conversations.",
    color: "#c47a20",
    side: "right" as const,
  },
  {
    icon: MessageSquare,
    title: "AI Chat Agents",
    description:
      "Custom-trained chatbots that understand your business, answer questions instantly, capture leads, and guide visitors through your sales funnel.",
    color: "#6b4fa0",
    side: "left" as const,
  },
  {
    icon: Megaphone,
    title: "Digital Marketing",
    description:
      "Data-driven marketing strategies powered by AI analytics. From SEO to paid ads, we maximize your reach and convert traffic into revenue.",
    color: "#22c55e",
    side: "right" as const,
  },
  {
    icon: Globe,
    title: "Web Design & Development",
    description:
      "Stunning, conversion-optimized websites built with cutting-edge technology. Responsive, fast, and designed to turn visitors into paying customers.",
    color: "#3352cc",
    side: "left" as const,
  },
  {
    icon: BarChart3,
    title: "Growth Analytics",
    description:
      "Track every metric that matters. Our AI-powered dashboards give you real-time insights into user behavior, conversions, and ROI.",
    color: "#c47a20",
    side: "right" as const,
  },
]

export default function ScrollShowcase() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const side = entry.target.getAttribute("data-side")
            if (side === "left") {
              entry.target.classList.add("animate-slide-in-left")
            } else {
              entry.target.classList.add("animate-slide-in-right")
            }
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = sectionRef.current?.querySelectorAll(".showcase-item")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="services" className="relative py-24 px-6">
      {/* Top gradient transition from marquee */}
      <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-[#060608] to-transparent pointer-events-none" />

      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-20">
          <p className="text-sm text-[#888] uppercase tracking-widest mb-4">
            What we build
          </p>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground text-balance">
            AI-Powered <span className="gradient-text">Solutions</span> That Scale
          </h2>
          <p className="mt-4 text-[#888] max-w-xl mx-auto leading-relaxed">
            From intelligent automation to stunning design, we deliver the full stack of digital innovation.
          </p>
        </div>

        {/* Vertical timeline */}
        <div className="relative">
          {/* Center line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-px hidden lg:block overflow-hidden">
            <div className="w-full h-full bg-gradient-to-b from-[#3352cc]/30 via-[#6b4fa0]/20 to-[#c47a20]/30" />
          </div>

          <div className="flex flex-col gap-16 lg:gap-20">
            {showcaseItems.map((item, index) => (
              <div
                key={item.title}
                data-side={item.side}
                className="showcase-item opacity-0 relative"
              >
                {/* Timeline dot */}
                <div
                  className="absolute left-1/2 top-8 -translate-x-1/2 w-4 h-4 rounded-full hidden lg:flex items-center justify-center z-10"
                  style={{ background: item.color }}
                >
                  <div
                    className="w-2 h-2 rounded-full bg-[#0a0a0a]"
                  />
                </div>

                <div
                  className={`flex flex-col lg:flex-row items-center gap-8 lg:gap-16 ${
                    item.side === "right" ? "lg:flex-row-reverse" : ""
                  }`}
                >
                  {/* Content */}
                  <div className={`flex-1 ${item.side === "right" ? "lg:text-right" : "lg:text-left"}`}>
                    <div className={`flex items-center gap-3 mb-4 ${item.side === "right" ? "lg:justify-end" : ""}`}>
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center"
                        style={{ background: `${item.color}15` }}
                      >
                        <item.icon size={24} style={{ color: item.color }} />
                      </div>
                      <span className="text-xs font-mono uppercase tracking-wider text-[#555]">
                        0{index + 1}
                      </span>
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-3">
                      {item.title}
                    </h3>
                    <p className="text-[#888] leading-relaxed max-w-md" style={item.side === "right" ? { marginLeft: "auto" } : {}}>
                      {item.description}
                    </p>
                  </div>

                  {/* Visual card */}
                  <div className="flex-1 w-full">
                    <div
                      className="relative rounded-2xl border border-[#1a1a1a] bg-[#0e0e10] p-8 overflow-hidden group hover:border-[#282828] transition-all duration-500"
                    >
                      {/* Animated gradient background */}
                      <div
                        className="absolute inset-0 opacity-[0.04] group-hover:opacity-[0.08] transition-opacity duration-500"
                        style={{
                          background: `radial-gradient(circle at ${item.side === "left" ? "80% 20%" : "20% 80%"}, ${item.color}, transparent 70%)`,
                        }}
                      />

                      {/* Corner accent */}
                      <div
                        className="absolute top-0 right-0 w-20 h-20 opacity-10"
                        style={{
                          background: `radial-gradient(circle at top right, ${item.color}, transparent 70%)`,
                        }}
                      />

                      {/* Mock interface */}
                      <div className="relative z-10 space-y-4">
                        <div className="flex items-center gap-2 mb-6">
                          <div className="w-3 h-3 rounded-full bg-[#ef4444]/60" />
                          <div className="w-3 h-3 rounded-full bg-[#eab308]/60" />
                          <div className="w-3 h-3 rounded-full bg-[#22c55e]/60" />
                          <div className="ml-4 flex-1 h-5 rounded-md bg-[#161618]" />
                        </div>

                        {/* Dynamic content based on service type */}
                        {index % 3 === 0 && (
                          <div className="space-y-3">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${item.color}20` }}>
                                <item.icon size={16} style={{ color: item.color }} />
                              </div>
                              <div className="flex-1 h-4 rounded bg-[#161618]" />
                            </div>
                            <div className="ml-11 space-y-2">
                              <div className="h-3 rounded bg-[#161618] w-[90%]" />
                              <div className="h-3 rounded bg-[#161618] w-[75%]" />
                              <div className="h-3 rounded bg-[#161618] w-[60%]" />
                            </div>
                            <div className="flex gap-2 ml-11 mt-4">
                              <div className="px-4 py-2 rounded-full text-xs font-medium" style={{ background: `${item.color}15`, color: item.color }}>Active</div>
                              <div className="px-4 py-2 rounded-full bg-[#161618] text-xs text-[#666]">Processing</div>
                            </div>
                          </div>
                        )}
                        {index % 3 === 1 && (
                          <div className="space-y-3">
                            <div className="flex gap-2">
                              {[40, 65, 85, 50, 70, 90, 55].map((h, i) => (
                                <div key={i} className="flex-1 flex flex-col justify-end" style={{ height: "80px" }}>
                                  <div className="rounded-t transition-all duration-700" style={{ height: `${h}%`, background: `${item.color}${i % 2 === 0 ? "30" : "18"}` }} />
                                </div>
                              ))}
                            </div>
                            <div className="flex justify-between text-xs text-[#444]">
                              <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
                            </div>
                          </div>
                        )}
                        {index % 3 === 2 && (
                          <div className="space-y-3">
                            {[1, 2, 3].map((_, i) => (
                              <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-[#0a0a0c]">
                                <div className="w-8 h-8 rounded-full" style={{ background: `${item.color}${20 - i * 5}` }} />
                                <div className="flex-1 space-y-1.5">
                                  <div className="h-3 rounded bg-[#161618] w-[70%]" />
                                  <div className="h-2 rounded bg-[#161618] w-[50%]" />
                                </div>
                                <div className="w-16 h-6 rounded-full" style={{ background: `${item.color}15` }} />
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Scan line effect on hover */}
                      <div
                        className="absolute left-0 right-0 h-px opacity-0 group-hover:animate-[scan-line_3s_ease-in-out_infinite]"
                        style={{ background: `linear-gradient(90deg, transparent, ${item.color}40, transparent)` }}
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
