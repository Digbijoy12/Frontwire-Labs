"use client"

import { useEffect, useState } from "react"

export default function Preloader() {
  const [progress, setProgress] = useState(0)
  const [isExiting, setIsExiting] = useState(false)
  const [isHidden, setIsHidden] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => setIsExiting(true), 300)
          setTimeout(() => setIsHidden(true), 1000)
          return 100
        }
        return prev + 2
      })
    }, 30)

    return () => clearInterval(interval)
  }, [])

  if (isHidden) return null

  return (
    <div
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#0a0a0a] transition-opacity duration-700 ${
        isExiting ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      <div
        className="flex flex-col items-center gap-8"
        style={{
          animation: "preloader-fade-in 0.6s ease-out forwards",
        }}
      >
        {/* Logo text with matching gradient */}
        <h1
          className="text-4xl md:text-6xl font-serif font-bold tracking-tight gradient-text"
          style={{
            animation: "preloader-pulse 2s ease-in-out infinite",
          }}
        >
          FrontWire Labs
        </h1>

        {/* Progress bar */}
        <div className="w-48 md:w-64 h-[2px] bg-[#222] rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-100 ease-out"
            style={{
              width: `${progress}%`,
              background: "linear-gradient(90deg, #c47a20, #6b4fa0, #3352cc)",
            }}
          />
        </div>

        {/* Progress percentage */}
        <p className="text-sm text-[#888] font-sans tabular-nums">
          {progress}%
        </p>
      </div>
    </div>
  )
}
