"use client"

import { useEffect, useRef } from "react"

export default function HeroVideoAnimation() {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    let animFrame: number
    let time = 0

    const resize = () => {
      const rect = containerRef.current?.getBoundingClientRect()
      if (!rect) return
      const dpr = Math.min(window.devicePixelRatio, 2)
      canvas.width = rect.width * dpr
      canvas.height = rect.height * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }

    resize()
    window.addEventListener("resize", resize)

    const draw = () => {
      const rect = containerRef.current?.getBoundingClientRect()
      if (!rect || !ctx) return
      const w = rect.width
      const h = rect.height
      time += 0.006

      ctx.clearRect(0, 0, w, h)

      // Dark background
      ctx.fillStyle = "#080810"
      ctx.fillRect(0, 0, w, h)

      // Subtle grid
      ctx.strokeStyle = "rgba(51, 82, 204, 0.04)"
      ctx.lineWidth = 0.5
      const gridSize = 40
      for (let x = 0; x < w; x += gridSize) {
        ctx.beginPath()
        ctx.moveTo(x, 0)
        ctx.lineTo(x, h)
        ctx.stroke()
      }
      for (let y = 0; y < h; y += gridSize) {
        ctx.beginPath()
        ctx.moveTo(0, y)
        ctx.lineTo(w, y)
        ctx.stroke()
      }

      const cx = w * 0.5
      const cy = h * 0.5
      const radius = Math.min(w, h) * 0.32

      // Outer glow ring
      for (let i = 3; i > 0; i--) {
        const glowR = radius * (1.1 + i * 0.12)
        const grad = ctx.createRadialGradient(cx, cy, glowR * 0.8, cx, cy, glowR)
        grad.addColorStop(0, "transparent")
        grad.addColorStop(0.5, `rgba(51, 82, 204, ${0.015 * i})`)
        grad.addColorStop(1, "transparent")
        ctx.fillStyle = grad
        ctx.beginPath()
        ctx.arc(cx, cy, glowR, 0, Math.PI * 2)
        ctx.fill()
      }

      // Longitude lines -- thicker and more visible
      for (let i = 0; i < 14; i++) {
        const angle = (i / 14) * Math.PI + time
        ctx.beginPath()
        for (let t = 0; t <= Math.PI; t += 0.04) {
          const x = cx + radius * Math.sin(t) * Math.cos(angle)
          const y = cy + radius * Math.cos(t)
          if (t === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        }
        ctx.strokeStyle = `rgba(100, 140, 255, ${0.15 + Math.sin(time + i) * 0.05})`
        ctx.lineWidth = 1
        ctx.stroke()
      }

      // Latitude lines
      for (let i = 1; i < 9; i++) {
        const latAngle = (i / 9) * Math.PI
        const r = radius * Math.sin(latAngle)
        const yPos = cy + radius * Math.cos(latAngle)
        ctx.beginPath()
        ctx.ellipse(cx, yPos, r, r * 0.3, 0, 0, Math.PI * 2)
        ctx.strokeStyle = `rgba(100, 140, 255, ${0.1 + Math.sin(time * 0.5 + i) * 0.04})`
        ctx.lineWidth = 0.8
        ctx.stroke()
      }

      // Glowing dots on globe surface -- bigger, brighter
      const dotCount = 40
      for (let i = 0; i < dotCount; i++) {
        const phi = (i / dotCount) * Math.PI * 2 + time * 0.25
        const theta = Math.sin(i * 0.7 + time * 0.15) * Math.PI * 0.85
        const dx = radius * Math.sin(theta) * Math.cos(phi)
        const dy = radius * Math.cos(theta)
        const dz = radius * Math.sin(theta) * Math.sin(phi)

        if (dz > -radius * 0.15) {
          const dotX = cx + dx
          const dotY = cy + dy
          const depth = (dz + radius) / (2 * radius)
          const dotSize = 2 + depth * 3

          const grad = ctx.createRadialGradient(dotX, dotY, 0, dotX, dotY, dotSize * 5)
          const color = i % 3 === 0 ? "80,120,255" : i % 3 === 1 ? "220,150,50" : "140,100,200"
          grad.addColorStop(0, `rgba(${color}, ${0.7 * depth})`)
          grad.addColorStop(1, "transparent")
          ctx.fillStyle = grad
          ctx.beginPath()
          ctx.arc(dotX, dotY, dotSize * 5, 0, Math.PI * 2)
          ctx.fill()

          ctx.fillStyle = `rgba(${color}, ${0.9 * depth})`
          ctx.beginPath()
          ctx.arc(dotX, dotY, dotSize, 0, Math.PI * 2)
          ctx.fill()
        }
      }

      // Connection lines between dots
      for (let i = 0; i < 18; i++) {
        const phi1 = (i / 18) * Math.PI * 2 + time * 0.25
        const theta1 = Math.sin(i * 0.7 + time * 0.15) * Math.PI * 0.85
        const x1 = cx + radius * Math.sin(theta1) * Math.cos(phi1)
        const y1 = cy + radius * Math.cos(theta1)
        const z1 = radius * Math.sin(theta1) * Math.sin(phi1)

        const j = (i + 4) % 18
        const phi2 = (j / 18) * Math.PI * 2 + time * 0.25
        const theta2 = Math.sin(j * 0.7 + time * 0.15) * Math.PI * 0.85
        const x2 = cx + radius * Math.sin(theta2) * Math.cos(phi2)
        const y2 = cy + radius * Math.cos(theta2)
        const z2 = radius * Math.sin(theta2) * Math.sin(phi2)

        if (z1 > -radius * 0.15 && z2 > -radius * 0.15) {
          ctx.beginPath()
          ctx.moveTo(x1, y1)
          ctx.lineTo(x2, y2)
          const avgZ = ((z1 + z2) / 2 + radius) / (2 * radius)
          ctx.strokeStyle = `rgba(80, 120, 255, ${0.1 * avgZ})`
          ctx.lineWidth = 0.7
          ctx.stroke()
        }
      }

      // Orbiting ring
      ctx.beginPath()
      ctx.ellipse(cx, cy, radius * 1.25, radius * 0.38, time * 0.4, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(140, 100, 200, 0.12)"
      ctx.lineWidth = 1.2
      ctx.stroke()

      // Second orbiting ring
      ctx.beginPath()
      ctx.ellipse(cx, cy, radius * 1.15, radius * 0.28, -time * 0.3 + 1, 0, Math.PI * 2)
      ctx.strokeStyle = "rgba(220, 150, 50, 0.08)"
      ctx.lineWidth = 0.8
      ctx.stroke()

      // Pulse ring expanding
      const pulsePhase = time % 4
      const pulseRadius = radius * (1 + pulsePhase / 4)
      const pulseOpacity = 0.12 * (1 - pulsePhase / 4)
      ctx.beginPath()
      ctx.arc(cx, cy, pulseRadius, 0, Math.PI * 2)
      ctx.strokeStyle = `rgba(80, 120, 255, ${pulseOpacity})`
      ctx.lineWidth = 1.5
      ctx.stroke()

      // Data stream particles flowing around
      for (let i = 0; i < 30; i++) {
        const streamAngle = time * 0.7 + (i / 30) * Math.PI * 2
        const streamR = radius * 1.35 + Math.sin(time * 1.5 + i) * 25
        const sx = cx + Math.cos(streamAngle) * streamR
        const sy = cy + Math.sin(streamAngle) * streamR * 0.42

        ctx.fillStyle = `rgba(220, 150, 50, ${0.4 + Math.sin(time + i) * 0.25})`
        ctx.beginPath()
        ctx.arc(sx, sy, 1.5, 0, Math.PI * 2)
        ctx.fill()
      }

      // Center ambient glow
      const centerGlow = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius * 0.5)
      centerGlow.addColorStop(0, "rgba(80, 120, 255, 0.08)")
      centerGlow.addColorStop(1, "transparent")
      ctx.fillStyle = centerGlow
      ctx.beginPath()
      ctx.arc(cx, cy, radius * 0.5, 0, Math.PI * 2)
      ctx.fill()

      // Floating labels -- LARGE, BRIGHT, READABLE
      const labels = [
        { text: "AI Voice Agents", icon: "mic" },
        { text: "AI Chat Agents", icon: "chat" },
        { text: "Web Development", icon: "code" },
        { text: "Digital Marketing", icon: "trend" },
      ]
      labels.forEach((label, idx) => {
        const la = time * 0.15 + (idx / labels.length) * Math.PI * 2
        const lr = radius * 1.55 + Math.sin(time * 0.8 + idx * 2) * 15
        const lx = cx + Math.cos(la) * lr
        const ly = cy + Math.sin(la) * lr * 0.48
        const labelOpacity = 0.6 + Math.sin(time + idx) * 0.15

        // Pill background -- larger
        ctx.font = "bold 13px Inter, system-ui, sans-serif"
        const metrics = ctx.measureText(label.text)
        const padX = 16
        const padY = 10
        const pillW = metrics.width + padX * 2
        const pillH = 18 + padY * 2

        // Shadow behind pill
        ctx.fillStyle = `rgba(0, 0, 0, ${labelOpacity * 0.5})`
        ctx.beginPath()
        ctx.roundRect(lx - pillW / 2 + 2, ly - pillH / 2 + 2, pillW, pillH, 20)
        ctx.fill()

        // Pill background
        ctx.fillStyle = `rgba(14, 14, 20, ${labelOpacity * 0.9})`
        ctx.beginPath()
        ctx.roundRect(lx - pillW / 2, ly - pillH / 2, pillW, pillH, 20)
        ctx.fill()

        // Pill border
        ctx.strokeStyle = `rgba(80, 120, 255, ${labelOpacity * 0.3})`
        ctx.lineWidth = 1
        ctx.stroke()

        // Label text -- BRIGHT WHITE
        ctx.font = "bold 13px Inter, system-ui, sans-serif"
        ctx.fillStyle = `rgba(255, 255, 255, ${labelOpacity})`
        ctx.textAlign = "center"
        ctx.textBaseline = "middle"
        ctx.fillText(label.text, lx, ly)
      })

      animFrame = requestAnimationFrame(draw)
    }

    draw()

    return () => {
      window.removeEventListener("resize", resize)
      cancelAnimationFrame(animFrame)
    }
  }, [])

  return (
    <div
      ref={containerRef}
      className="relative w-full rounded-2xl overflow-hidden border border-[#1a1a2a]"
      style={{ aspectRatio: "16/8" }}
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ display: "block" }}
      />
      {/* Corner glow accents */}
      <div className="absolute top-0 left-0 w-40 h-40 bg-[#3352cc]/[0.04] blur-3xl rounded-full pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-40 h-40 bg-[#c47a20]/[0.04] blur-3xl rounded-full pointer-events-none" />
      {/* Overlay glow edges */}
      <div className="absolute inset-0 pointer-events-none rounded-2xl" style={{
        boxShadow: "inset 0 0 80px rgba(51,82,204,0.06), inset 0 0 160px rgba(0,0,0,0.6)"
      }} />
    </div>
  )
}
