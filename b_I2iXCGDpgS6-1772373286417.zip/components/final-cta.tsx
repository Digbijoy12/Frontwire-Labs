"use client"

import { useEffect, useRef } from "react"
import { Phone, Calendar, ArrowRight } from "lucide-react"

export default function FinalCta() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = sectionRef.current?.querySelectorAll(".reveal")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="contact" className="py-24 px-6">
      <div className="max-w-4xl mx-auto">
        <div className="relative rounded-3xl border border-[#222] bg-[#111]/80 backdrop-blur-sm p-12 md:p-16 text-center overflow-hidden">
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#3352cc]/5 via-transparent to-[#c47a20]/5 pointer-events-none" />
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[1px] bg-gradient-to-r from-transparent via-[#3352cc]/40 to-transparent" />

          <div className="relative z-10">
            <h2 className="reveal opacity-0 text-3xl md:text-5xl font-bold text-foreground text-balance">
              What are you waiting for?
            </h2>
            <p className="reveal opacity-0 delay-100 mt-6 text-[#888] max-w-2xl mx-auto leading-relaxed text-pretty">
              Your website is a 24/7 salesperson that works for you even when you
              sleep. Do not just settle for an ordinary one. Go beyond with
              FrontWire Labs -- AI-powered, conversion-optimized, and built to scale.
            </p>

            {/* Dual CTA */}
            <div className="reveal opacity-0 delay-200 mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="tel:+13527902398"
                className="group inline-flex items-center gap-3 px-8 py-4 text-base font-medium rounded-full bg-[#3352cc] text-[#ffffff] hover:bg-[#3352cc]/90 transition-all btn-glow"
              >
                <Phone size={18} />
                Call Now
              </a>
              <a
                href="https://cal.com/frontwire-labs"
                target="_blank"
                rel="noopener noreferrer"
                className="group inline-flex items-center gap-3 px-8 py-4 text-base font-medium rounded-full bg-foreground text-background hover:bg-foreground/90 transition-all"
              >
                <Calendar size={18} />
                Book Appointment
                <ArrowRight
                  size={16}
                  className="group-hover:translate-x-1 transition-transform"
                />
              </a>
            </div>

            {/* Trust badges */}
            <div className="reveal opacity-0 delay-300 flex flex-wrap items-center justify-center gap-6 mt-8 text-sm text-[#666]">
              <span>Unlimited revisions</span>
              <div className="w-px h-4 bg-[#333]" />
              <span>AI-Powered</span>
              <div className="w-px h-4 bg-[#333]" />
              <span>Fast delivery</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
