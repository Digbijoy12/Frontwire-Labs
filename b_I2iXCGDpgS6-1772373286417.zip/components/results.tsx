"use client"

import { useEffect, useRef } from "react"
import { Layers, Briefcase, DollarSign } from "lucide-react"

const capabilities = [
  "AI Integration", "AI Voice Agents", "AI Chat Agents", "Digital Marketing",
  "Landing Pages", "Web Design", "Development", "SEO", "E-commerce",
]

export default function Results() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = sectionRef.current?.querySelectorAll(".reveal")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="results" className="relative py-24 px-6">
      {/* Background accent orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-[#3352cc]/[0.015] blur-3xl" />
      </div>
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <h2 className="reveal opacity-0 text-3xl md:text-5xl font-bold text-foreground text-balance">
            Results That Speak for Themselves
          </h2>
          <p className="reveal opacity-0 delay-100 mt-4 text-[#888] max-w-xl mx-auto leading-relaxed">
            Premium quality, expert execution, half the cost. See why we are different.
          </p>
        </div>

        {/* Results cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 - All-in-One */}
          <div className="reveal opacity-0 delay-200 p-8 rounded-2xl border border-[#222] bg-[#111] hover:border-[#333] transition-all duration-300 card-glow">
            <div className="w-12 h-12 rounded-xl bg-[#3352cc]/10 flex items-center justify-center text-[#3352cc] mb-6">
              <Layers size={24} />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              All-in-One AI Powerhouse
            </h3>
            <p className="text-sm text-[#888] mb-6 leading-relaxed">
              AI agents, design, development, and marketing. All in one place. Just seamless execution.
            </p>
            <div className="flex flex-wrap gap-2">
              {capabilities.map((cap) => (
                <span
                  key={cap}
                  className="px-3 py-1.5 text-xs rounded-full border border-[#222] bg-[#0a0a0a] text-[#aaa]"
                >
                  {cap}
                </span>
              ))}
            </div>
          </div>

          {/* Card 2 - Experience */}
          <div className="reveal opacity-0 delay-300 p-8 rounded-2xl border border-[#222] bg-[#111] hover:border-[#333] transition-all duration-300 card-glow">
            <div className="w-12 h-12 rounded-xl bg-[#c47a20]/10 flex items-center justify-center text-[#c47a20] mb-6">
              <Briefcase size={24} />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              3 Years. 70+ Projects
            </h3>
            <p className="text-sm text-[#888] leading-relaxed">
              From branding to e-commerce, we have done it all. Every service perfected, every client delighted.
            </p>
          </div>

          {/* Card 3 - Pricing */}
          <div className="reveal opacity-0 delay-400 p-8 rounded-2xl border border-[#222] bg-[#111] hover:border-[#333] transition-all duration-300 card-glow">
            <div className="w-12 h-12 rounded-xl bg-[#22c55e]/10 flex items-center justify-center text-[#22c55e] mb-6">
              <DollarSign size={24} />
            </div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs px-2 py-1 rounded-full bg-[#22c55e]/10 text-[#22c55e] font-medium">
                Savings: Highest
              </span>
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2">
              Transparent Pricing
            </h3>
            <p className="text-sm text-[#888] leading-relaxed">
              Enterprise-grade work at startup-friendly prices. Same quality, half the cost. No compromises.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
