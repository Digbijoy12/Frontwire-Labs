"use client"

import { useEffect, useRef, useCallback } from "react"

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  radius: number
  opacity: number
  color: string
  pulse: number
  pulseSpeed: number
}

interface GridNode {
  x: number
  y: number
  opacity: number
  pulseOffset: number
}

export default function AnimatedBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const particlesRef = useRef<Particle[]>([])
  const gridNodesRef = useRef<GridNode[]>([])
  const mouseRef = useRef({ x: -1000, y: -1000 })
  const animationFrameRef = useRef<number>(0)
  const timeRef = useRef(0)

  const colors = ["#3352cc", "#6b4fa0", "#c47a20", "#2563eb"]

  const initParticles = useCallback(
    (width: number, height: number) => {
      const count = Math.min(Math.floor((width * height) / 12000), 120)
      const particles: Particle[] = []
      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          vx: (Math.random() - 0.5) * 0.4,
          vy: (Math.random() - 0.5) * 0.4,
          radius: Math.random() * 2 + 0.5,
          opacity: Math.random() * 0.5 + 0.1,
          color: colors[Math.floor(Math.random() * colors.length)],
          pulse: Math.random() * Math.PI * 2,
          pulseSpeed: 0.01 + Math.random() * 0.02,
        })
      }
      return particles
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  )

  const initGridNodes = useCallback((width: number, height: number) => {
    const nodes: GridNode[] = []
    const spacing = 80
    for (let x = 0; x < width; x += spacing) {
      for (let y = 0; y < height; y += spacing) {
        nodes.push({
          x: x + (Math.random() - 0.5) * 20,
          y: y + (Math.random() - 0.5) * 20,
          opacity: 0.02 + Math.random() * 0.03,
          pulseOffset: Math.random() * Math.PI * 2,
        })
      }
    }
    return nodes
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const resize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
      particlesRef.current = initParticles(canvas.width, canvas.height)
      gridNodesRef.current = initGridNodes(canvas.width, canvas.height)
    }

    resize()
    window.addEventListener("resize", resize)

    const handleMouse = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY }
    }
    window.addEventListener("mousemove", handleMouse)

    const animate = () => {
      if (!ctx || !canvas) return
      timeRef.current += 0.016

      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Draw grid nodes (subtle dot grid)
      const nodes = gridNodesRef.current
      const mouse = mouseRef.current
      const time = timeRef.current

      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i]
        const pulse = Math.sin(time * 0.5 + n.pulseOffset) * 0.5 + 0.5
        const mdx = n.x - mouse.x
        const mdy = n.y - mouse.y
        const mDist = Math.sqrt(mdx * mdx + mdy * mdy)
        const mouseInfluence = mDist < 200 ? (1 - mDist / 200) * 0.15 : 0

        ctx.beginPath()
        ctx.arc(n.x, n.y, 1, 0, Math.PI * 2)
        ctx.fillStyle = `rgba(51, 82, 204, ${n.opacity * pulse + mouseInfluence})`
        ctx.fill()

        // Highlight grid nodes near mouse
        if (mDist < 150) {
          ctx.beginPath()
          ctx.arc(n.x, n.y, 3 + mouseInfluence * 8, 0, Math.PI * 2)
          ctx.fillStyle = `rgba(51, 82, 204, ${mouseInfluence * 0.3})`
          ctx.fill()
        }
      }

      // Draw subtle grid lines connecting nearby nodes
      for (let i = 0; i < nodes.length; i++) {
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = nodes[i].x - nodes[j].x
          const dy = nodes[i].y - nodes[j].y
          const dist = Math.sqrt(dx * dx + dy * dy)

          if (dist < 90 && dist > 30) {
            const mdx1 = nodes[i].x - mouse.x
            const mdy1 = nodes[i].y - mouse.y
            const mDist1 = Math.sqrt(mdx1 * mdx1 + mdy1 * mdy1)
            const mouseGlow = mDist1 < 250 ? (1 - mDist1 / 250) * 0.1 : 0

            ctx.beginPath()
            ctx.moveTo(nodes[i].x, nodes[i].y)
            ctx.lineTo(nodes[j].x, nodes[j].y)
            ctx.strokeStyle = `rgba(51, 82, 204, ${0.015 + mouseGlow})`
            ctx.lineWidth = 0.5
            ctx.stroke()
          }
        }
      }

      // Draw floating particles
      const particles = particlesRef.current
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i]

        p.x += p.vx
        p.y += p.vy
        p.pulse += p.pulseSpeed
        const pulseOpacity = (Math.sin(p.pulse) * 0.3 + 0.7)

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1

        // Particle glow
        const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.radius * 4)
        gradient.addColorStop(0, p.color)
        gradient.addColorStop(1, "transparent")
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.radius * 4, 0, Math.PI * 2)
        ctx.fillStyle = gradient
        ctx.globalAlpha = p.opacity * pulseOpacity * 0.3
        ctx.fill()

        // Particle core
        ctx.beginPath()
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2)
        ctx.fillStyle = p.color
        ctx.globalAlpha = p.opacity * pulseOpacity
        ctx.fill()

        // Connections between close particles
        for (let j = i + 1; j < particles.length; j++) {
          const p2 = particles[j]
          const dx = p.x - p2.x
          const dy = p.y - p2.y
          const dist = Math.sqrt(dx * dx + dy * dy)

          if (dist < 120) {
            ctx.beginPath()
            ctx.moveTo(p.x, p.y)
            ctx.lineTo(p2.x, p2.y)
            ctx.strokeStyle = p.color
            ctx.globalAlpha = (1 - dist / 120) * 0.06
            ctx.lineWidth = 0.5
            ctx.stroke()
          }
        }

        // Mouse interaction -- glow lines to cursor
        const pmdx = p.x - mouse.x
        const pmdy = p.y - mouse.y
        const pmDist = Math.sqrt(pmdx * pmdx + pmdy * pmdy)
        if (pmDist < 250) {
          ctx.beginPath()
          ctx.moveTo(p.x, p.y)
          ctx.lineTo(mouse.x, mouse.y)
          ctx.strokeStyle = p.color
          ctx.globalAlpha = (1 - pmDist / 250) * 0.2
          ctx.lineWidth = 0.8
          ctx.stroke()

          // Slight attraction to mouse
          p.vx += (mouse.x - p.x) * 0.00003
          p.vy += (mouse.y - p.y) * 0.00003
        }
      }

      // Draw ambient glow orbs (large, slow, low opacity)
      const orbCount = 3
      for (let i = 0; i < orbCount; i++) {
        const angle = time * 0.1 + (i * Math.PI * 2) / orbCount
        const cx = canvas.width * 0.5 + Math.cos(angle) * canvas.width * 0.3
        const cy = canvas.height * 0.5 + Math.sin(angle * 0.7) * canvas.height * 0.3
        const orbGrad = ctx.createRadialGradient(cx, cy, 0, cx, cy, 200)
        orbGrad.addColorStop(0, i === 0 ? "rgba(51,82,204,0.04)" : i === 1 ? "rgba(107,79,160,0.03)" : "rgba(196,122,32,0.03)")
        orbGrad.addColorStop(1, "transparent")
        ctx.globalAlpha = 1
        ctx.fillStyle = orbGrad
        ctx.beginPath()
        ctx.arc(cx, cy, 200, 0, Math.PI * 2)
        ctx.fill()
      }

      ctx.globalAlpha = 1
      animationFrameRef.current = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", resize)
      window.removeEventListener("mousemove", handleMouse)
      cancelAnimationFrame(animationFrameRef.current)
    }
  }, [initParticles, initGridNodes])

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ width: "100%", height: "100%" }}
      aria-hidden="true"
    />
  )
}
