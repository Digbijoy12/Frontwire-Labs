"use client"

import { useEffect, useRef } from "react"
import { Phone, Palette, Code, Rocket, Calendar } from "lucide-react"

const steps = [
  {
    icon: Phone,
    title: "Discovery",
    description:
      "We start with a quick conversation to learn about your business, goals, and audience. Together, we map out AI opportunities, design needs, and a clear timeline.",
  },
  {
    icon: Palette,
    title: "Design",
    description:
      "We create simple first drafts and quickly turn them into polished designs. You'll see progress as we go and can give feedback anytime. The focus: looking great and working for your audience.",
  },
  {
    icon: Code,
    title: "Development",
    description:
      "We turn the approved design into a fast, mobile-friendly website with integrated AI agents, built-in SEO, analytics, and performance optimization.",
  },
  {
    icon: Rocket,
    title: "Launch",
    description:
      "We set up hosting, connect your domain, and make the site live. After launch, we track performance and make any fine-tuning needed so you get the best results.",
  },
]

export default function HowItWorks() {
  const sectionRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up")
          }
        })
      },
      { threshold: 0.1 }
    )

    const elements = sectionRef.current?.querySelectorAll(".reveal")
    elements?.forEach((el) => observer.observe(el))

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="how-it-works"
      className="relative py-24 px-6"
    >
      {/* Subtle background accent */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/4 -left-32 w-96 h-96 rounded-full bg-[#3352cc]/[0.02] blur-3xl" />
        <div className="absolute bottom-1/4 -right-32 w-96 h-96 rounded-full bg-[#c47a20]/[0.02] blur-3xl" />
      </div>
      <div className="max-w-6xl mx-auto">
        {/* Section header */}
        <div className="text-center mb-16">
          <p className="reveal opacity-0 text-sm text-[#888] uppercase tracking-widest mb-4">
            How it works
          </p>
          <h2 className="reveal opacity-0 delay-100 text-3xl md:text-5xl font-bold text-foreground text-balance">
            A clean, <span className="gradient-text">4-step</span> process
          </h2>
          <p className="reveal opacity-0 delay-200 mt-4 text-[#888] max-w-xl mx-auto leading-relaxed">
            We make it easy to get you a stunning, high-performing website. Fast, clear, and built to win customers.
          </p>
        </div>

        {/* CTA above steps */}
        <div className="reveal opacity-0 delay-200 text-center mb-12 flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href="tel:+13527902398"
            className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium rounded-full bg-[#3352cc] text-[#ffffff] hover:bg-[#3352cc]/90 transition-colors"
          >
            <Phone size={14} />
            Call for Free Discovery
          </a>
          <a
            href="https://cal.com/frontwire-labs"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium rounded-full border border-[#333] text-foreground hover:bg-[#ffffff08] transition-colors"
          >
            <Calendar size={14} />
            Book a Call
          </a>
        </div>

        {/* Steps grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((step, index) => (
            <div
              key={step.title}
              className="reveal opacity-0 group relative p-6 rounded-2xl border border-[#222] bg-[#111] hover:border-[#333] transition-all duration-300 card-glow"
              style={{ animationDelay: `${(index + 3) * 100}ms` }}
            >
              {/* Step number */}
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-[#3352cc]/10 flex items-center justify-center text-[#3352cc]">
                  <step.icon size={20} />
                </div>
                <span className="text-xs font-mono text-[#555] uppercase tracking-wider">
                  Step {index + 1}
                </span>
              </div>

              <h3 className="text-lg font-semibold text-foreground mb-3">
                {step.title}
              </h3>
              <p className="text-sm text-[#888] leading-relaxed">
                {step.description}
              </p>

              {/* Connector line for desktop */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-3 w-6 h-px bg-[#333]" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
