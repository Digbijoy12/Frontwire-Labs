import Preloader from "@/components/preloader"
import Navbar from "@/components/navbar"
import Hero from "@/components/hero"
import ServicesMarquee from "@/components/services-marquee"
import ScrollShowcase from "@/components/scroll-showcase"
import HowItWorks from "@/components/how-it-works"
import Results from "@/components/results"
import Comparison from "@/components/comparison"
import CtaBanner from "@/components/cta-banner"
import Features from "@/components/features"
import Faq from "@/components/faq"
import FinalCta from "@/components/final-cta"
import Footer from "@/components/footer"
import AnimatedBackground from "@/components/animated-background"

export default function Home() {
  return (
    <>
      <Preloader />
      <AnimatedBackground />
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <ServicesMarquee />
        <ScrollShowcase />
        <HowItWorks />
        <Results />
        <Comparison />
        <CtaBanner />
        <Features />
        <Faq />
        <FinalCta />
      </main>
      <Footer />
    </>
  )
}
